"""empty message

Revision ID: 652af2a5d923
Revises: 7a4d0c363512
Create Date: 2023-11-18 16:13:47.410596

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '652af2a5d923'
down_revision = '7a4d0c363512'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
