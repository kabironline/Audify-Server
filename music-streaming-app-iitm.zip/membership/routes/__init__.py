from .login import *
from .register import *
from .dashboard import *
from .edit_profile import *
from .avatar import *
from .delete import *